const asyncHandler=require('express-async-handler')


const Goal=require('../model/goalModel')
const User=require('../model/userModel')
const userModel = require('../model/userModel')
// @desc get goals
//@route GET/api/goals
//@acces Privite
const getGoals=asyncHandler(async(req,res)=>{
    const goals=await Goal.find({user:req.user.id})


    res.status(200).json(goals)
})

// @desc set goals
//@route POST/api/goals
//@acces Privite
const setGoals=asyncHandler(async(req,res)=>{
    if (!req.body.text){
        res.status(400)
        throw new Error('Please add the text')

    }
    const goals = await Goal.create({
        text:req.body.text,
        user:req.user.id,
        
    })
    res.status(200).json(goals )
})

// @desc Update goals
//@route PUT/api/goals/:id
//@acces Privite
const updateGoals=asyncHandler(async(req,res)=>{
    const goal=await Goal.findById(req.params.id)
    if(!goal){
        res.status(400)
        throw new Error('Goal not found')
    }


// check if user exist
if(!req.user){
    res.status(401)
    throw new Error('user not found')
}

//Make sure the logged in user matches the goal user
if(goal.user.toString()!==req.user.id){
    res.status(401)
    throw new Error('User not authorized')
}

    const updatedGoal=await Goal.findByIdAndUpdate(req.params.id,req.body,{
        new:true,
    })

    res.status(200).json(updatedGoal)
})

// @desc Delete goals
//@route DELETE/api/goals/:id
//@acces Privite
const deleteGoals=asyncHandler(async(req,res)=>{
    const goal=await Goal.findById(req.params.id)
    if(!goal){
        res.status(400)
        throw new Error('Goal not found')
    }

// check if user exist
if(!req.user){
    res.status(401)
    throw new Error('user not found')
}

//Make sure the logged in user matches the goal user
if(goal.user.toString()!==req.user.id){
    res.status(401)
    throw new Error('User not authorized')
}
    await goal.deleteOne({id:req.params.id})
    res.status(200).json({id:req.params.id})
}) 

module.exports={
    getGoals,setGoals,updateGoals,deleteGoals
}